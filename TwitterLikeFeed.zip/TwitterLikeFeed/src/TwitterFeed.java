import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TwitterFeed {
    public static void main(String[] args) throws Exception {

        //Path of the text file
        String tweetFile = "C:\\Users\\Liam\\IdeaProjects\\TwitterLikeFeed\\tweet.txt";
        String userFile = "C:\\Users\\Liam\\IdeaProjects\\TwitterLikeFeed\\user.txt";

        String outputFile = "output.txt";

        //Try and catch to be used to handle exceptions such as "file not found" or "Error reading file".
        try {
            //FileReader reads text files in the default encoding.
            BufferedReader bufferedReader = new BufferedReader(new FileReader(tweetFile));
            BufferedReader bufferedReader2 = new BufferedReader(new FileReader(userFile));

            String inputLine;
            //Adding lines from text file "tweet.txt" into an ArrayList
            List<String> lineList = new ArrayList<String>();
            while ((inputLine = bufferedReader.readLine()) != null) {
                lineList.add(inputLine);
            }
            String userLine;
            while ((userLine = bufferedReader.readLine()) != null) {
                lineList.add(userLine);
                System.out.println(userLine);
            }
            //Always close files
            bufferedReader.close();

            //Sorting everything inside the list in alphabetical order
            Collections.sort(lineList);
            //Filewriter used for writing streams of characters
            FileWriter fileWriter = new FileWriter(outputFile);
            //Printwriter prints formatted representations of objects to a text-output stream
            PrintWriter out = new PrintWriter(fileWriter);
            for (String outputLine : lineList) {
                System.out.println(outputLine);
            }
            //Force any buffered output bytes to be written out
            System.out.flush();
            //Close the Buffer
            System.out.close();
            fileWriter.close();
            //Print sorted List to console
            System.out.println(lineList);
            //Catch exceptions if file cannot be found
            }catch (FileNotFoundException e) {
                System.out.println("Unable to open file '" + tweetFile + "'");
            }
            //Catch exception is file cannot be read
            catch(IOException ex) {
                System.out.println("Error reading file '" + tweetFile + "'");
            }
    }

}
